import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  Clock, 
  ShieldCheck, 
  Send, 
  ShoppingBag, 
  CheckCircle2, 
  ArrowRight, 
  Utensils, 
  Package, 
  Users,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  PhoneCall,
  Check,
  Building2,
  Calendar
} from 'lucide-react';
import { Dish, CartItem, DayOfWeek } from '../types';
import { PACKAGING_BENEFITS, CORPORATE_PACKAGES } from '../data/menuData';
import { WEEKLY_MENUS } from '../data/weeklyMenuData';

interface HomeViewProps {
  todayDishes: Dish[];
  breakfastDishes: Dish[];
  onSelectDish: (dish: Dish) => void;
  onNavigateTab: (tab: string, day?: DayOfWeek) => void;
  onOpenCart: () => void;
  onAddToCart?: (item: Omit<CartItem, 'cartItemId'>) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  todayDishes,
  breakfastDishes,
  onSelectDish,
  onNavigateTab,
  onOpenCart,
  onAddToCart,
}) => {
  // Slider state
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Section 1 featured dishes pagination state (3 visible at a time)
  const [featuredPage, setFeaturedPage] = useState(0);

  // Corporate added state
  const [addedCorpId, setAddedCorpId] = useState<string | null>(null);

  // Hero Carousel slides (Panorámico 21:9 o 16:9)
  const slides = [
    {
      id: 'slide-1',
      tag: '🔥 DESPACHO CALIENTE • ZONA BANCARIA & OBARRIO',
      title: 'Tu almuerzo criollo auténtico listo a tiempo, sin hacer 1 minuto de fila.',
      description: 'Paila panameña del día cocinada a fuego lento, empacada en bandejas térmicas a 75°C y despachada directo a la recepción de tu piso o lista para retiro Pick & Go.',
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=2000&q=80',
      ctaPrimaryText: 'Pide tu almuerzo de hoy sin hacer filas',
      ctaPrimaryLink: 'https://wa.me/50762345678?text=Hola%20Eat%20%26%20Go!%20Quiero%20pedir%20mi%20almuerzo%20de%20hoy%20sin%20filas.',
      ctaSecondaryText: 'Ver Menú de la Semana',
      targetTab: 'semanal',
      targetSection: 'seccion-menu-semanal'
    },
    {
      id: 'slide-2',
      tag: '🌅 DISPONIBLE DESDE LAS 6:30 AM • COCINA MATUTINA',
      title: 'Desayunos Fijos Típicos: Hojaldres Crujientes, Bistec y Tortillas.',
      description: 'Arranca tu jornada laboral con sabor auténtico de fonda: carimañolas doradas con carne mechada, café criollo y chichas artesanales selladas sin esperas.',
      image: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=2000&q=80',
      ctaPrimaryText: 'Pedir Desayuno Express',
      ctaPrimaryLink: 'https://wa.me/50762345678?text=Hola%20Eat%20%26%20Go!%20Quiero%20pedir%20desayunos%20para%20la%20oficina.',
      ctaSecondaryText: 'Ver Desayunos Fijos',
      targetTab: null,
      targetSection: 'desayunos-fijos'
    },
    {
      id: 'slide-3',
      tag: '🏢 ALMUERZOS DE EQUIPO • ENTREGA SINCRONIZADA 12:00 MD',
      title: 'Combos Corporativos para 5 y 10 Personas con Factura Fiscal.',
      description: 'Bandejas térmicas trilaminadas compartimentadas para reuniones de trabajo y capacitaciones. Cero regueros, cero comida fría, 100% deducible con RUC.',
      image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=2000&q=80',
      ctaPrimaryText: 'Cotizar Almuerzo de Equipo',
      ctaPrimaryLink: 'https://wa.me/50762345678?text=Hola%20Eat%20%26%20Go!%20Necesito%20cotizar%20un%20paquete%20corporativo%20con%20factura.',
      ctaSecondaryText: 'Ver Opciones Empresa',
      targetTab: 'empresa',
      targetSection: 'combos-oficina'
    }
  ];

  // Auto-play for the Hero Slider
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [isPaused, slides.length]);

  const handlePrevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleNextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  // Section 1 logic: Take 3 dishes based on featuredPage
  const visibleFeaturedDishes = todayDishes.slice(featuredPage * 3, featuredPage * 3 + 3);
  const maxFeaturedPages = Math.ceil(todayDishes.length / 3);

  const handleAddCorporate = (pkg: typeof CORPORATE_PACKAGES[0]) => {
    if (onAddToCart) {
      onAddToCart({
        dishId: pkg.id,
        name: pkg.name,
        basePrice: pkg.price,
        unitPrice: pkg.price,
        quantity: 1,
        notes: `Paquete corporativo (${pkg.servings} personas) con entrega sincronizada a las 12:00 MD`,
        totalPrice: pkg.price,
      });
      setAddedCorpId(pkg.id);
      setTimeout(() => setAddedCorpId(null), 2200);
    } else {
      onNavigateTab('corporativo');
    }
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-8 sm:space-y-12 pb-16">
      {/* ========================================================================= */}
      {/* 2. HERO SECTION (Banner Principal)                                        */}
      {/* Estructura: 100% ancho, relación panorámica 21:9 o 16:9                   */}
      {/* Componente: Carrusel / Slider                                             */}
      {/* Flechas flotantes desenfocadas en los extremos + Dots parte inferior       */}
      {/* ========================================================================= */}
      <section 
        id="hero-slider"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        className="relative w-full aspect-[16/9] sm:aspect-[21/9] min-h-[380px] sm:min-h-[440px] rounded-2xl sm:rounded-3xl overflow-hidden bg-stone-950 text-white shadow-xl border border-stone-800"
      >
        {/* Slides */}
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
              index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
            }`}
          >
            {/* Background Image (Cover Panorámico) */}
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover filter contrast-110 brightness-90"
              referrerPolicy="no-referrer"
            />
            {/* Deep gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-950/85 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-transparent to-black/30" />

            {/* Content inside the slide */}
            <div className="absolute inset-0 flex flex-col justify-center px-6 sm:px-12 md:px-16 max-w-3xl z-10">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/25 border border-amber-500/40 text-amber-300 text-[11px] sm:text-xs font-black uppercase tracking-wider mb-3 w-fit">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                {slide.tag}
              </span>

              <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight leading-[1.12] text-white">
                {slide.title}
              </h1>

              <p className="mt-2.5 sm:mt-3.5 text-xs sm:text-sm md:text-base text-stone-300 leading-relaxed max-w-2xl font-normal">
                {slide.description}
              </p>

              {/* Action Buttons inside Hero */}
              <div className="mt-5 sm:mt-7 flex flex-wrap items-center gap-3">
                <a
                  href={slide.ctaPrimaryLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-black text-xs sm:text-sm shadow-md transition-transform active:scale-95"
                >
                  <Send className="w-4 h-4 fill-current" />
                  <span>{slide.ctaPrimaryText}</span>
                </a>

                <button
                  onClick={() => {
                    if (slide.targetTab) {
                      onNavigateTab(slide.targetTab);
                    } else {
                      scrollTo(slide.targetSection);
                    }
                  }}
                  className="flex items-center gap-2 px-4 py-3 rounded-xl bg-stone-900/80 hover:bg-stone-800 text-stone-200 border border-stone-700 font-bold text-xs sm:text-sm backdrop-blur-xs transition-colors"
                >
                  <Utensils className="w-4 h-4 text-amber-400" />
                  <span>{slide.ctaSecondaryText}</span>
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* Flechas de navegación flotantes (position: absolute) centradas verticalmente */}
        {/* Circulares con ligero desenfoque o transparencia */}
        <button
          onClick={handlePrevSlide}
          aria-label="Slide anterior"
          className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md text-white border border-white/20 flex items-center justify-center transition-all z-20 shadow-lg active:scale-95"
        >
          <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>

        <button
          onClick={handleNextSlide}
          aria-label="Siguiente slide"
          className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md text-white border border-white/20 flex items-center justify-center transition-all z-20 shadow-lg active:scale-95"
        >
          <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>

        {/* Paginador de puntos (Dots) flotante en la parte inferior central */}
        <div className="absolute bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
          {slides.map((_, dotIdx) => (
            <button
              key={dotIdx}
              onClick={() => setCurrentSlide(dotIdx)}
              aria-label={`Ir al slide ${dotIdx + 1}`}
              className={`h-2.5 rounded-full transition-all ${
                dotIdx === currentSlide
                  ? 'w-7 bg-amber-400 shadow-xs'
                  : 'w-2.5 bg-white/40 hover:bg-white/70'
              }`}
            />
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. NOTIFICATION / ACTION BAR (Banda de Acción Rápida)                     */}
      {/* Estructura: Bloque delgado y ancho con borde perimetral sutil (1px)       */}
      {/* Layout: Flexbox horizontal (justify-content: space-between; center)       */}
      {/* Logo/icono izq + Texto 1-2 líneas + Flecha en círculo color acento der   */}
      {/* ========================================================================= */}
      <section
        id="notification-action-bar"
        onClick={() => onNavigateTab('empresa')}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            onNavigateTab('empresa');
          }
        }}
        className="w-full bg-white hover:bg-amber-50/60 border border-stone-200/90 hover:border-amber-400 rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-xs transition-all cursor-pointer group flex items-center justify-between gap-4"
      >
        {/* Izquierda: Logo secundario o icono */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-700 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <ShieldCheck className="w-5 h-5 text-amber-600" />
          </div>

          {/* Centro: Texto de 1 o 2 líneas */}
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-extrabold text-stone-900 tracking-tight block truncate">
                ¿Reunión o almuerzo corporativo hoy en tu empresa?
              </span>
              <span className="hidden sm:inline-block text-[10px] uppercase font-black px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300">
                Factura Fiscal
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-stone-600 leading-snug mt-0.5 truncate">
              Despachamos bandejas ejecutivas calientes (75°C) con entrega garantizada a las 12:00 MD directo a recepción.
            </p>
          </div>
        </div>

        {/* Derecha: Flecha indicadora de acción (dentro de un círculo color de acento) */}
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-amber-500 group-hover:bg-amber-400 text-stone-950 flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:translate-x-1">
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </div>
      </section>

      {/* ========================================================================= */}
      {/* MENÚS DE LA SEMANA (LUNES A SÁBADO) - ACCESO DIRECTO DESDE HOME           */}
      {/* ========================================================================= */}
      <section id="seccion-menu-semanal" className="scroll-mt-28">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
          <div>
            <div className="text-[11px] font-black uppercase tracking-widest text-amber-800 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-600" />
              <span>PROGRAMACIÓN GASTRONÓMICA SEMANAL • DE LUNES A SÁBADO</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-stone-900 tracking-tight leading-none">
              Menús de la Semana
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Cada día una especialidad criolla diferente. Selecciona tu día para ver el menú y pedir sin esperas:
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('semanal')}
            className="text-xs sm:text-sm font-bold text-amber-700 hover:text-amber-900 flex items-center gap-1.5 self-start sm:self-auto bg-amber-50 px-3.5 py-2 rounded-xl border border-amber-200/80 hover:border-amber-300 transition-all shrink-0"
          >
            <span>Ver Programación Completa</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 6 Day Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {WEEKLY_MENUS.map((dayMenu) => {
            return (
              <div
                key={dayMenu.dayId}
                onClick={() => onNavigateTab('semanal', dayMenu.dayId)}
                className="group bg-white rounded-2xl border border-stone-200/90 hover:border-amber-400 p-3 sm:p-3.5 flex flex-col justify-between shadow-xs hover:shadow-md transition-all cursor-pointer hover:-translate-y-0.5"
              >
                <div>
                  {/* Día y Badge */}
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="text-xs font-black uppercase tracking-wider text-stone-900">
                      {dayMenu.shortName}
                    </span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 truncate">
                      {dayMenu.badge.split(' ')[0]}
                    </span>
                  </div>

                  {/* Imagen del plato estrella */}
                  <div className="relative aspect-square rounded-xl overflow-hidden mb-2.5 bg-stone-100 border border-stone-100">
                    <img
                      src={dayMenu.starDishImage}
                      alt={dayMenu.starDishName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-1.5 right-1.5 bg-stone-950/80 backdrop-blur-xs text-amber-400 text-[10px] font-black px-1.5 py-0.5 rounded">
                      ${dayMenu.starDishPrice.toFixed(2)}
                    </div>
                  </div>

                  {/* Nombre del plato */}
                  <h4 className="font-extrabold text-xs text-stone-900 line-clamp-2 leading-tight group-hover:text-amber-700 transition-colors">
                    {dayMenu.starDishName}
                  </h4>
                  <p className="text-[10px] text-stone-500 mt-1 line-clamp-1">
                    {dayMenu.dishes.length} platos disponibles
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-stone-100 flex items-center justify-between text-[11px] font-bold text-amber-700 group-hover:text-amber-800">
                  <span>Ver Menú</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. SECTION 1: GRILLA DESTACADA (Cards de Alto Impacto)                    */}
      {/* Cabecera: Subtítulo superior + H2 grande y pesado + Flechas + "Ver todas" */}
      {/* Grilla: 3 columnas (grid-template-columns: repeat(3, 1fr))                */}
      {/* Cards: Grandes, verticales, esquinas redondeadas, background cover total   */}
      {/* No hay texto por fuera; todo el contenido visual vive dentro de la imagen  */}
      {/* ========================================================================= */}
      <section id="seccion-grilla-destacada" className="scroll-mt-28">
        {/* Cabecera de Sección */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
          <div>
            <div className="text-[11px] font-black uppercase tracking-widest text-amber-800 mb-1 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
              <span>LO MÁS PEDIDO DE HOY • PAILA CALIENTE</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-stone-900 tracking-tight leading-none">
              Platos Estrella de Hoy
            </h2>
          </div>

          {/* A la derecha del título: Controles de navegación (Flechas) y enlace secundario ("Ver todas") */}
          <div className="flex items-center gap-3 self-start sm:self-auto">
            <button
              onClick={() => onNavigateTab('menu')}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 hover:underline flex items-center gap-1"
            >
              <span>Ver todas las opciones</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <div className="flex items-center gap-1.5 ml-2">
              <button
                onClick={() => setFeaturedPage((prev) => Math.max(0, prev - 1))}
                disabled={featuredPage === 0}
                aria-label="Página anterior de destacados"
                className="w-8 h-8 rounded-lg bg-stone-100 hover:bg-stone-200 disabled:opacity-30 disabled:cursor-not-allowed text-stone-800 flex items-center justify-center transition-colors border border-stone-200"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setFeaturedPage((prev) => (prev + 1 < maxFeaturedPages ? prev + 1 : 0))}
                aria-label="Siguiente página de destacados"
                className="w-8 h-8 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 flex items-center justify-center transition-colors border border-stone-200"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* La Grilla: 3 columnas (grid-template-columns: repeat(3, 1fr)) */}
        {/* Tarjetas grandes, verticales, esquinas redondeadas con imágenes de fondo completas */}
        {/* Ningún texto por fuera: Todo el contenido vive DENTRO del contenedor de la imagen */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {visibleFeaturedDishes.map((dish) => (
            <div
              key={dish.id}
              className="relative aspect-[3/4] sm:aspect-[4/5] min-h-[400px] rounded-2xl sm:rounded-3xl overflow-hidden shadow-md group border border-stone-800 cursor-pointer"
              onClick={() => onSelectDish(dish)}
            >
              {/* Background cover image */}
              <img
                src={dish.image}
                alt={dish.name}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />

              {/* Gradient overlay to ensure text contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/70 to-black/20" />

              {/* TOP FLOTANTE DENTRO DE LA IMAGEN: Badge & Precio */}
              <div className="absolute top-4 inset-x-4 flex items-center justify-between z-10">
                <span className="bg-stone-950/80 backdrop-blur-md text-amber-400 text-[10px] sm:text-xs font-black uppercase tracking-wider px-2.5 py-1 rounded-md border border-amber-500/30 shadow-sm">
                  {dish.badge || '🔥 Paila del Día'}
                </span>

                <span className="bg-white/95 text-stone-950 text-sm sm:text-base font-black px-3 py-1 rounded-lg shadow-md">
                  ${dish.price.toFixed(2)}
                </span>
              </div>

              {/* BOTTOM CONTENIDO DENTRO DE LA IMAGEN: Tipografía pesada + Botón comanda */}
              <div className="absolute bottom-0 inset-x-0 p-5 sm:p-6 z-10 flex flex-col justify-end text-white">
                <h3 className="text-xl sm:text-2xl font-black tracking-tight leading-tight text-white group-hover:text-amber-300 transition-colors">
                  {dish.name}
                </h3>

                <p className="text-xs text-stone-300 line-clamp-2 mt-1.5 leading-relaxed">
                  {dish.description}
                </p>

                <div className="mt-3 text-[11px] font-semibold text-amber-300 flex items-center gap-1">
                  <span>Guarnición a elegir:</span>
                  <span className="text-stone-300 font-normal">Arroz, tajadas o patacones</span>
                </div>

                <div className="mt-4 pt-3 border-t border-white/15">
                  <button
                    id={`btn-hero-dish-${dish.id}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectDish(dish);
                    }}
                    className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs sm:text-sm font-black rounded-xl transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4 text-stone-950" />
                    <span>Elegir Acompañamiento y Pedir</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. SECTION 2: GRILLA CATEGÓRICA (Bento Box / Banners horizontales)        */}
      {/* Cabecera: Título principal a la izquierda                                  */}
      {/* Grilla: 3 columnas x 2 filas (6 tarjetas horizontales tipo banner)         */}
      {/* Layout 50/50: Texto a la izq + Imagen recortada a la der saliéndose límites*/}
      {/* Cada tarjeta usa un color de fondo sólido distinto                        */}
      {/* ========================================================================= */}
      <section id="seccion-grilla-categorica" className="scroll-mt-28">
        <div className="mb-5">
          <h2 className="text-2xl sm:text-3xl font-black text-stone-900 tracking-tight">
            Explora por Categoría Criolla
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
            Selecciona el tipo de preparación para ver opciones y ordenar al instante.
          </p>
        </div>

        {/* CSS Grid: 3 columnas x 2 filas (repeat(3, 1fr)) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1: Paila del Día (Fondo Mostaza / Ámbar Sólido) */}
          <div
            onClick={() => scrollTo('seccion-grilla-destacada')}
            className="h-32 sm:h-36 rounded-2xl bg-[#FEF08A] border border-amber-300/80 p-4 relative overflow-hidden flex items-center justify-between cursor-pointer group shadow-xs hover:shadow-md transition-all"
          >
            <div className="w-1/2 z-10 flex flex-col justify-between h-full">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-900 block">
                  Cocción Lenta
                </span>
                <h3 className="font-black text-sm sm:text-base text-stone-900 leading-tight mt-0.5 group-hover:text-amber-900 transition-colors">
                  Paila del Día & Guisados
                </h3>
              </div>
              <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                <span>Ver platos</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>

            <div className="w-1/2 h-full flex items-center justify-end relative">
              <img
                src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80"
                alt="Pailas del Día"
                className="w-28 sm:w-32 h-28 sm:h-32 rounded-2xl object-cover -mr-4 -mb-4 transform scale-110 shadow-lg group-hover:scale-115 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Card 2: Sopas & Sancochos (Fondo Verde Salvia Sólido) */}
          <div
            onClick={() => onNavigateTab('menu')}
            className="h-32 sm:h-36 rounded-2xl bg-[#BBF7D0] border border-emerald-300/80 p-4 relative overflow-hidden flex items-center justify-between cursor-pointer group shadow-xs hover:shadow-md transition-all"
          >
            <div className="w-1/2 z-10 flex flex-col justify-between h-full">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-950 block">
                  Caldos Criollos
                </span>
                <h3 className="font-black text-sm sm:text-base text-stone-900 leading-tight mt-0.5 group-hover:text-emerald-900 transition-colors">
                  Sancochos & Sopas
                </h3>
              </div>
              <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                <span>Con arroz blanco</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>

            <div className="w-1/2 h-full flex items-center justify-end relative">
              <img
                src="https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=400&q=80"
                alt="Sancocho Criollo"
                className="w-28 sm:w-32 h-28 sm:h-32 rounded-2xl object-cover -mr-4 -mb-4 transform scale-110 shadow-lg group-hover:scale-115 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Card 3: Desayunos Fijos (Fondo Melocotón / Terracota Sólido) */}
          <div
            onClick={() => scrollTo('desayunos-fijos')}
            className="h-32 sm:h-36 rounded-2xl bg-[#FED7AA] border border-orange-300/80 p-4 relative overflow-hidden flex items-center justify-between cursor-pointer group shadow-xs hover:shadow-md transition-all"
          >
            <div className="w-1/2 z-10 flex flex-col justify-between h-full">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-orange-950 block">
                  Desde 6:30 AM
                </span>
                <h3 className="font-black text-sm sm:text-base text-stone-900 leading-tight mt-0.5 group-hover:text-orange-900 transition-colors">
                  Desayunos Típicos
                </h3>
              </div>
              <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                <span>Hojaldres & Bistec</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>

            <div className="w-1/2 h-full flex items-center justify-end relative">
              <img
                src="https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=400&q=80"
                alt="Desayunos Típicos"
                className="w-28 sm:w-32 h-28 sm:h-32 rounded-2xl object-cover -mr-4 -mb-4 transform scale-110 shadow-lg group-hover:scale-115 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Card 4: Combos Oficina (Fondo Azul Corporativo Sólido) */}
          <div
            onClick={() => scrollTo('combos-oficina')}
            className="h-32 sm:h-36 rounded-2xl bg-[#BAE6FD] border border-sky-300/80 p-4 relative overflow-hidden flex items-center justify-between cursor-pointer group shadow-xs hover:shadow-md transition-all"
          >
            <div className="w-1/2 z-10 flex flex-col justify-between h-full">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-sky-950 block">
                  Reuniones & Equipos
                </span>
                <h3 className="font-black text-sm sm:text-base text-stone-900 leading-tight mt-0.5 group-hover:text-sky-900 transition-colors">
                  Combos Oficina (5 & 10)
                </h3>
              </div>
              <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                <span>Factura fiscal</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>

            <div className="w-1/2 h-full flex items-center justify-end relative">
              <img
                src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=400&q=80"
                alt="Combos Oficina"
                className="w-28 sm:w-32 h-28 sm:h-32 rounded-2xl object-cover -mr-4 -mb-4 transform scale-110 shadow-lg group-hover:scale-115 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Card 5: Chichas & Bebidas Selladas (Fondo Rosa Pastel Sólido) */}
          <div
            onClick={() => onNavigateTab('menu')}
            className="h-32 sm:h-36 rounded-2xl bg-[#FECDD3] border border-rose-300/80 p-4 relative overflow-hidden flex items-center justify-between cursor-pointer group shadow-xs hover:shadow-md transition-all"
          >
            <div className="w-1/2 z-10 flex flex-col justify-between h-full">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-rose-950 block">
                  Botellas PET Selladas
                </span>
                <h3 className="font-black text-sm sm:text-base text-stone-900 leading-tight mt-0.5 group-hover:text-rose-900 transition-colors">
                  Chichas Artesanales
                </h3>
              </div>
              <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                <span>Raspadura & Limón</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>

            <div className="w-1/2 h-full flex items-center justify-end relative">
              <img
                src="https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=400&q=80"
                alt="Chichas Artesanales"
                className="w-28 sm:w-32 h-28 sm:h-32 rounded-2xl object-cover -mr-4 -mb-4 transform scale-110 shadow-lg group-hover:scale-115 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Card 6: Guarniciones & Frituras (Fondo Piedra / Crema Sólido) */}
          <div
            onClick={() => onNavigateTab('menu')}
            className="h-32 sm:h-36 rounded-2xl bg-[#E7E5E4] border border-stone-300 p-4 relative overflow-hidden flex items-center justify-between cursor-pointer group shadow-xs hover:shadow-md transition-all"
          >
            <div className="w-1/2 z-10 flex flex-col justify-between h-full">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-stone-700 block">
                  Acompañamientos
                </span>
                <h3 className="font-black text-sm sm:text-base text-stone-900 leading-tight mt-0.5 group-hover:text-amber-800 transition-colors">
                  Guarniciones & Frituras
                </h3>
              </div>
              <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                <span>Tajadas & Patacones</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>

            <div className="w-1/2 h-full flex items-center justify-end relative">
              <img
                src="https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=400&q=80"
                alt="Guarniciones y Frituras"
                className="w-28 sm:w-32 h-28 sm:h-32 rounded-2xl object-cover -mr-4 -mb-4 transform scale-110 shadow-lg group-hover:scale-115 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* SECCIÓN INTERACTIVA ANCLADA: Desayunos Fijos Criollos (6:30 AM) */}
      <section id="desayunos-fijos" className="scroll-mt-28 bg-amber-50/70 border border-amber-200/80 rounded-2xl sm:rounded-3xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-amber-800 mb-1">
              <Clock className="w-4 h-4 text-amber-700" />
              <span>Disponible Diario de 6:30 a.m. a 11:00 a.m.</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-stone-900 tracking-tight">
              Desayunos Fijos Criollos
            </h2>
            <p className="text-stone-600 text-xs sm:text-sm mt-0.5">
              Hojaldres recién fritas, tortillas de maíz, carimañolas doradas y bistec encebollado con salsa criolla.
            </p>
          </div>

          <span className="text-xs font-bold text-stone-700 bg-white px-3 py-1.5 rounded-lg border border-amber-200 self-start sm:self-auto">
            ☕ Café criollo & Chichas frías selladas
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {breakfastDishes.map((dish) => (
            <div
              key={dish.id}
              className="bg-white rounded-xl border border-amber-200/60 p-3.5 flex flex-col justify-between shadow-xs hover:shadow-sm transition-all"
            >
              <div className="flex gap-3">
                <img
                  src={dish.image}
                  alt={dish.name}
                  className="w-16 h-16 rounded-lg object-cover shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-sm text-stone-900 truncate">
                    {dish.name}
                  </h3>
                  <p className="text-[11px] text-stone-500 line-clamp-2 mt-0.5">
                    {dish.description}
                  </p>
                  <p className="text-amber-700 font-black text-sm mt-1">
                    ${dish.price.toFixed(2)}
                  </p>
                </div>
              </div>

              <button
                id={`btn-add-breakfast-${dish.id}`}
                onClick={() => onSelectDish(dish)}
                className="mt-3 w-full py-1.5 px-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <span>+ Agregar a Comanda</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* SECCIÓN INTERACTIVA ANCLADA: Prueba de Empaques Térmicos y Calidad */}
      <section id="empaques-termicos" className="scroll-mt-28 rounded-2xl sm:rounded-3xl bg-stone-900 text-white p-6 sm:p-10 border border-stone-800">
        <div className="max-w-3xl mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Cero Informalidad • Grado Alimenticio</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-stone-100 tracking-tight">
            Garantía Térmica: Empaques Troquelados & Botellas Selladas
          </h2>
          <p className="text-stone-300 text-xs sm:text-sm mt-2 leading-relaxed">
            Eliminamos cualquier riesgo de regueros, bolsas húmedas o comida fría en tu escritorio. Nuestro sistema de envasado está diseñado para oficinas corporativas.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {PACKAGING_BENEFITS.map((item, idx) => (
            <div
              key={idx}
              className="bg-stone-800/80 rounded-xl p-4 sm:p-5 border border-stone-700/80 flex flex-col justify-between"
            >
              <div>
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs mb-3">
                  0{idx + 1}
                </div>
                <h3 className="font-bold text-sm text-stone-100 mb-1.5">
                  {item.title}
                </h3>
                <p className="text-xs text-stone-400 leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-700/60 flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Estándar Eat & Go</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECCIÓN INTERACTIVA ANCLADA: Combos para Reuniones de Oficina (5 & 10 Personas) */}
      <section id="combos-oficina" className="scroll-mt-28">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-amber-800 mb-1">
              <Users className="w-4 h-4 text-amber-700" />
              <span>Almuerzos de Equipo & Capacitaciones</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-stone-900 tracking-tight">
              Bandejas para Reuniones de Oficina
            </h2>
            <p className="text-stone-600 text-xs sm:text-sm mt-0.5">
              Entrega sincronizada a las 12:00 MD en bandejas térmicas con factura fiscal para tu empresa.
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('corporativo')}
            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 group self-start sm:self-auto py-1"
          >
            <span>Cotizar pedidos mayores</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {CORPORATE_PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              className="bg-white rounded-2xl border border-stone-200 overflow-hidden flex flex-col justify-between shadow-xs hover:border-amber-400 transition-all"
            >
              <div>
                <div className="h-44 bg-stone-100 relative">
                  <img
                    src={pkg.image}
                    alt={pkg.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-2.5 right-2.5 bg-stone-950 text-amber-400 font-black text-base px-3 py-1 rounded-lg shadow-sm">
                    ${pkg.price.toFixed(2)}
                  </span>
                  <span className="absolute top-2.5 left-2.5 bg-white text-stone-950 text-xs font-black px-2.5 py-1 rounded-md shadow-xs flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    {pkg.servings} Personas
                  </span>
                </div>

                <div className="p-5">
                  <h3 className="font-extrabold text-base text-stone-900 leading-snug">
                    {pkg.name}
                  </h3>
                  <p className="text-xs text-stone-600 mt-1.5">
                    {pkg.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-stone-100">
                    <p className="text-[11px] font-bold text-stone-700 uppercase tracking-wider mb-2">
                      Incluye:
                    </p>
                    <ul className="space-y-1.5 text-xs text-stone-600">
                      {pkg.includes.map((item, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0">
                <button
                  id={`btn-home-add-corp-${pkg.id}`}
                  onClick={() => handleAddCorporate(pkg)}
                  className={`w-full py-2.5 px-4 font-black text-xs rounded-xl flex items-center justify-center gap-2 transition-all ${
                    addedCorpId === pkg.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-xs active:scale-95'
                  }`}
                >
                  {addedCorpId === pkg.id ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>¡Agregado a Comanda!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Agregar Paquete a la Comanda (${pkg.price.toFixed(2)})</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. TEXT BLOCK (Bloque SEO / Descriptivo)                                   */}
      {/* Estructura: Contenedor simple de texto                                     */}
      {/* Layout: Ancho completo del contenedor (100%), alineación a la izquierda   */}
      {/* Texto de cuerpo regular: Útil para indexación de buscadores o info legal   */}
      {/* ========================================================================= */}
      <section 
        id="bloque-seo-descriptivo" 
        className="w-full bg-white rounded-2xl border border-stone-200/80 p-6 sm:p-8 text-left space-y-4"
      >
        <div className="border-b border-stone-100 pb-3">
          <h3 className="text-base sm:text-lg font-bold text-stone-900 tracking-tight">
            Gastronomía Criolla Panameña & Despacho Corporativo en Ciudad de Panamá
          </h3>
          <p className="text-xs text-amber-800 font-semibold mt-0.5">
            Información del servicio, estándares de cocina y condiciones de entrega
          </p>
        </div>

        <div className="space-y-3 text-xs sm:text-sm text-stone-600 leading-relaxed max-w-none">
          <p>
            <strong>Eat & Go</strong> nace con la misión de dignificar y acelerar el consumo del almuerzo criollo tradicional en los principales ejes financieros y empresariales de Panamá, específicamente en las áreas de Obarrio, Calle 50, Marbella, San Francisco y Costa del Este. Nuestro modelo sustituye las largas esperas en filas y la informalidad de los despachos convencionales por un sistema estructurado de comanda digital y envasado térmico de grado alimenticio.
          </p>

          <p>
            Cada jornada inicia a las 5:00 a.m. con la preparación artesanal de los platos emblemáticos de la fonda panameña: mondongo a la culantro cocinado a fuego lento, pollo guisado en sofrito criollo, sancocho tradicional de gallina con ñame suave y corvina fresca frita al ajillo. Todos los platos principales se sirven acompañados de opciones clásicas como arroz blanco o arroz con guandú fresco, tajadas de plátano maduro al punto o patacones crujientes recién hechos.
          </p>

          <p>
            Para garantizar que el plato llegue a tu escritorio en condiciones óptimas de textura y temperatura, empleamos bandejas trilaminadas troqueladas herméticamente a 75°C. Este empaque cuenta con compartimentos independientes que impiden que los jugos de las carnes humedezcan las frituras o el arroz antes del consumo, previniendo derrames y condensaciones en áreas de oficina. Las bebidas artesanales (limonada con raspadura y maracuyá natural) se dispensan en botellas PET transparentes con precinto de seguridad intacto.
          </p>

          <p>
            En el ámbito corporativo, ofrecemos soluciones de alimentación para reuniones de trabajo, talleres y juntas directivas con paquetes para 5 y 10 comensales, entregados con puntualidad sincronizada antes de las 12:00 MD. Emitimos factura fiscal formal con RUC y DV conforme a las regulaciones de la Dirección General de Ingresos (DGI), permitiendo una deducibilidad clara de gastos para personas jurídicas y empresas.
          </p>
        </div>
      </section>
    </div>
  );
};
