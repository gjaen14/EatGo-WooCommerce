import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Clock, 
  MapPin, 
  PhoneCall, 
  Building2, 
  ClipboardList, 
  ChevronDown, 
  Flame, 
  Utensils, 
  ShieldCheck, 
  Check 
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  cartCount,
  cartTotal,
  onOpenCart,
}) => {
  const [deliveryContext, setDeliveryContext] = useState<'oficina' | 'pickgo'>('oficina');
  const [showLocationDropdown, setShowLocationDropdown] = useState(false);

  const handleCategoryClick = (sectionIdOrTab: string) => {
    if (
      sectionIdOrTab === 'home' ||
      sectionIdOrTab === 'semanal' ||
      sectionIdOrTab === 'empresa' ||
      sectionIdOrTab === 'contacto' ||
      sectionIdOrTab === 'navidad' ||
      sectionIdOrTab === 'menu'
    ) {
      onSelectTab(sectionIdOrTab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // If currently not on 'home', switch to 'home' first then scroll
    if (currentTab !== 'home') {
      onSelectTab('home');
      setTimeout(() => {
        const el = document.getElementById(sectionIdOrTab);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      const el = document.getElementById(sectionIdOrTab);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="w-full text-stone-100 shadow-md">
      {/* ========================================================================= */}
      {/* FILA 1: UTILIDADES Y CUENTA (Fondo oscuro, altura holgada, gap: 20px)      */}
      {/* ========================================================================= */}
      <div className="bg-stone-950 border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-4">
          {/* Izquierda: Bloque de Logo Principal */}
          <button
            onClick={() => {
              onSelectTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 text-left group focus:outline-none shrink-0"
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black text-xl sm:text-2xl shadow-md group-hover:bg-amber-400 transition-colors">
              EG
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-xl sm:text-2xl tracking-tight text-white leading-none">
                  EAT & GO
                </span>
                <span className="hidden sm:inline-block text-[10px] uppercase font-extrabold tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Criollo Express
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-stone-400 font-medium mt-0.5 leading-none">
                Sabor de Paila Auténtico • Despacho Sin Filas
              </p>
            </div>
          </button>

          {/* Derecha: Clúster de iconos utilitarios (4 a 5 items) */}
          {/* Layout: display: flex; justify-content: flex-end; gap: 20px; alineación horizontal */}
          <div className="hidden lg:flex items-center justify-end gap-5">
            {/* Item 1: Ubicación & Retiro */}
            <button 
              onClick={() => {
                onSelectTab('contacto');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2 text-left cursor-pointer group"
            >
              <div className="w-8 h-8 rounded-lg bg-stone-900 border border-stone-800 group-hover:border-amber-500/50 flex items-center justify-center text-amber-400 transition-colors">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-[12px] font-bold text-stone-200 group-hover:text-amber-400 transition-colors">
                  Dónde Comer & Retirar
                </span>
                <span className="text-[10px] text-stone-400">
                  Calle 50 • Pick & Go
                </span>
              </div>
            </button>

            {/* Item 2: Horarios */}
            <button 
              onClick={() => {
                onSelectTab('contacto');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2 text-left"
            >
              <div className="w-8 h-8 rounded-lg bg-stone-900 border border-stone-800 flex items-center justify-center text-emerald-400">
                <Clock className="w-4 h-4" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-[12px] font-bold text-stone-200">
                  6:30 AM - 3:30 PM
                </span>
                <span className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Cocina Despachando
                </span>
              </div>
            </button>

            {/* Item 3: Soporte WhatsApp */}
            <a
              href="https://wa.me/50762345678?text=Hola%20Eat%20%26%20Go!%20Quiero%20hacer%20un%20pedido%20o%20consultar%20el%20menú."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-left group"
            >
              <div className="w-8 h-8 rounded-lg bg-stone-900 border border-stone-800 group-hover:border-emerald-500 flex items-center justify-center text-emerald-400 transition-colors">
                <PhoneCall className="w-4 h-4" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-[12px] font-bold text-stone-200 group-hover:text-emerald-400 transition-colors">
                  +507 6234-5678
                </span>
                <span className="text-[10px] text-stone-400">
                  Atención Express
                </span>
              </div>
            </a>

            {/* Item 4: Corporativo / Factura */}
            <button
              onClick={() => {
                onSelectTab('empresa');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2 text-left group"
            >
              <div className="w-8 h-8 rounded-lg bg-stone-900 border border-stone-800 group-hover:border-amber-500 flex items-center justify-center text-amber-400 transition-colors">
                <Building2 className="w-4 h-4" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-[12px] font-bold text-stone-200 group-hover:text-amber-400 transition-colors">
                  Empresas
                </span>
                <span className="text-[10px] text-stone-400">
                  Factura con RUC
                </span>
              </div>
            </button>

            {/* Item 5: Mi Pedido */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2 text-left group"
            >
              <div className="w-8 h-8 rounded-lg bg-stone-900 border border-stone-800 group-hover:border-amber-500 flex items-center justify-center text-stone-300 group-hover:text-white transition-colors">
                <ClipboardList className="w-4 h-4" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-[12px] font-bold text-stone-200 group-hover:text-amber-400 transition-colors">
                  Mi Comanda
                </span>
                <span className="text-[10px] text-stone-400">
                  {cartCount > 0 ? `${cartCount} plato(s)` : 'Vacía'}
                </span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* FILA 2: NAVEGACIÓN PRINCIPAL Y CARRITO (STICKY ON SCROLL)                  */}
      {/* ========================================================================= */}
      <nav 
        aria-label="Navegación principal y carrito"
        className="sticky top-0 z-40 bg-stone-900/98 backdrop-blur-md border-b border-stone-800"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
          {/* Izquierda: Menú de categorías principales en línea */}
          {/* El item activo tiene un estilo visual distintivo en forma de píldora/botón */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {/* Página 1: Inicio */}
            <button
              id="nav-btn-home"
              onClick={() => handleCategoryClick('home')}
              className={`whitespace-nowrap px-3.5 py-1.5 text-xs font-bold transition-all ${
                currentTab === 'home'
                  ? 'rounded-full bg-amber-500 text-stone-950 shadow-sm font-black'
                  : 'rounded-full text-stone-300 hover:text-white hover:bg-stone-800'
              }`}
            >
              🏠 Inicio
            </button>

            {/* Página 2: Menú Semanal */}
            <button
              id="nav-btn-semanal"
              onClick={() => handleCategoryClick('semanal')}
              className={`whitespace-nowrap px-3.5 py-1.5 text-xs font-bold transition-all ${
                currentTab === 'semanal'
                  ? 'rounded-full bg-amber-500 text-stone-950 shadow-sm font-black'
                  : 'rounded-full text-stone-300 hover:text-white hover:bg-stone-800'
              }`}
            >
              📅 Menú Semanal (Lun - Sáb)
            </button>

            {/* Página 3: Empresas */}
            <button
              id="nav-btn-empresa"
              onClick={() => handleCategoryClick('empresa')}
              className={`whitespace-nowrap px-3.5 py-1.5 text-xs font-bold transition-all ${
                currentTab === 'empresa'
                  ? 'rounded-full bg-amber-500 text-stone-950 shadow-sm font-black'
                  : 'rounded-full text-stone-300 hover:text-white hover:bg-stone-800'
              }`}
            >
              🏢 Empresas & Catering
            </button>

            {/* Página 4: Dónde Comer & Retirar */}
            <button
              id="nav-btn-contacto"
              onClick={() => handleCategoryClick('contacto')}
              className={`whitespace-nowrap px-3.5 py-1.5 text-xs font-bold transition-all ${
                currentTab === 'contacto'
                  ? 'rounded-full bg-amber-500 text-stone-950 shadow-sm font-black'
                  : 'rounded-full text-stone-300 hover:text-white hover:bg-stone-800'
              }`}
            >
              📍 Dónde Comer & Retirar
            </button>

            {/* Módulo Especial: Navidad */}
            <button
              id="nav-btn-navidad"
              onClick={() => handleCategoryClick('navidad')}
              className={`whitespace-nowrap px-3 py-1.5 text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentTab === 'navidad'
                  ? 'rounded-full bg-emerald-600 text-white shadow-sm font-black'
                  : 'rounded-full text-emerald-300 hover:text-emerald-100 hover:bg-emerald-950/60 border border-emerald-500/30'
              }`}
            >
              <span>🎄 Especial Navideño</span>
              <span className="text-[9px] bg-red-600 text-white px-1.5 py-0.5 rounded-full font-black">
                15 Nov
              </span>
            </button>

            {/* Accesos Rápidos Complementarios */}
            <button
              id="cat-btn-hoy"
              onClick={() => handleCategoryClick('seccion-grilla-destacada')}
              className="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-medium text-stone-400 hover:text-stone-200 hover:bg-stone-800/60 transition-colors"
            >
              🔥 Platos de Hoy
            </button>

            <button
              id="cat-btn-desayunos"
              onClick={() => handleCategoryClick('desayunos-fijos')}
              className="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-medium text-stone-400 hover:text-stone-200 hover:bg-stone-800/60 transition-colors"
            >
              🌅 Desayunos
            </button>
          </div>

          {/* Derecha: Selector de Contexto + Botón CTA Principal (Carrito) */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Selector de Contexto (Ubicación / Modalidad de entrega) */}
            <div className="relative">
              <button
                id="context-selector-btn"
                onClick={() => setShowLocationDropdown(!showLocationDropdown)}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700/80 border border-stone-700 text-xs font-semibold text-stone-200 transition-colors"
              >
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate max-w-[130px]">
                  {deliveryContext === 'oficina' ? 'Entrega en Oficina' : 'Retiro Pick & Go'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
              </button>

              {showLocationDropdown && (
                <div 
                  className="absolute right-0 top-full mt-2 w-56 bg-stone-900 border border-stone-700 rounded-xl shadow-2xl p-2 z-50 text-xs"
                >
                  <div className="px-2 py-1 text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                    Modo de Entrega
                  </div>
                  <button
                    onClick={() => {
                      setDeliveryContext('oficina');
                      setShowLocationDropdown(false);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors ${
                      deliveryContext === 'oficina'
                        ? 'bg-amber-500/20 text-amber-300 font-bold'
                        : 'text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-white">Despacho a Oficina</div>
                      <div className="text-[10px] text-stone-400">Obarrio, Calle 50, Marbella</div>
                    </div>
                    {deliveryContext === 'oficina' && <Check className="w-4 h-4 text-amber-400" />}
                  </button>

                  <button
                    onClick={() => {
                      setDeliveryContext('pickgo');
                      setShowLocationDropdown(false);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors mt-1 ${
                      deliveryContext === 'pickgo'
                        ? 'bg-amber-500/20 text-amber-300 font-bold'
                        : 'text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-white">Retiro Pick & Go (10 min)</div>
                      <div className="text-[10px] text-stone-400">Mostrador Express sin fila</div>
                    </div>
                    {deliveryContext === 'pickgo' && <Check className="w-4 h-4 text-amber-400" />}
                  </button>
                </div>
              )}
            </div>

            {/* Botón CTA Principal (Carrito): Rompe la línea visual por su color de alto contraste y forma rectangular */}
            <button
              id="open-cart-button"
              onClick={onOpenCart}
              className="flex items-center gap-2 sm:gap-2.5 px-3.5 sm:px-4 py-2 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-stone-950 font-black text-xs sm:text-sm rounded-md shadow-lg transition-transform active:scale-[0.98] border border-amber-300 tracking-tight"
            >
              <ShoppingBag className="w-4 h-4 text-stone-950 fill-stone-950/20 shrink-0" />
              <span className="hidden sm:inline font-extrabold uppercase tracking-wide">
                Comanda
              </span>
              
              <span className="flex items-center gap-1.5 pl-1 sm:pl-1.5 border-l border-stone-950/30">
                <span className="bg-stone-950 text-amber-400 font-black text-[11px] px-1.5 py-0.2 rounded-xs">
                  {cartCount}
                </span>
                <span className="font-black text-stone-950">
                  ${cartTotal.toFixed(2)}
                </span>
              </span>
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
};
